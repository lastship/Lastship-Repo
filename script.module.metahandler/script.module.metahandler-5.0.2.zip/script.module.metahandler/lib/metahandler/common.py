# -*- coding: utf-8 -*-
'''
    metahandler XBMC Addon
    Copyright (C) 2020 Anis3

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
'''
import os, xbmcaddon, xbmc

addon = xbmcaddon.Addon('script.module.metahandler')
addon_path = addon.getAddonInfo('path')
profile_path = addon.getAddonInfo('profile')
settings_file = os.path.join(addon_path, 'resources', 'settings.xml')
addon_version = addon.getAddonInfo('version')


def log(msg, level=xbmc.LOGNOTICE):
    xbmc.log('%s: %s' % (addon.getAddonInfo('name'), msg), level)


def show_settings():
    addon.openSettings()


def get_setting(setting):
    return addon.getSetting(setting)
